Author: Connor Gomes
Student ID: 101231686
Description: This program takes two values from the user. 
			 One value is a float which represents an EMF 
			 and the other is an integer which represents 
			 a UUID. Every UUID has an EMF value associated 
			 with it. When the user is finished entering the data
			 the program detects for errors, if an error is present
			 the program notifies the user and terminates. If there are no errors
			 The program prints the unsorted list along with the 
			 number of elements they entered and then prints the
			 sorted list along with the number of elements they enetered.



List of Files:
	1. 	Assignment#1.c
	2. 	README.txt


Instructions for compilation & launching
	1.	First compile the code with the gcc compiler.
			a. Run the following command "gcc Assignment#1.c -o <DesiredExecutableName>"
	2. 	Now that the code is compiled we need to run the new executable file.
			a. Run "./<DesiredExecutableName>" to run the executable file.
