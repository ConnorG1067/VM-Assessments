Connor Gomes
101231686

Programs encrypts and decrypts messages the user inputs
Uses an xor operation on the previous byte and the current byte's bit

List of files
    - Assignment2.c
    - README.txt

Compilation and Launching
    - To compile run "gcc Assignment2.c -o <DesiredFileName>"
    - To launch run "./<DesiredFileName>"
