Author: Connor Gomes
Student ID: 101231686


List of files
	main.c
	defs.h
	Evidence.c
	init.c

Decription:
	Used for logging ghost hunter information
	The user may add, delete or view the evidence
	within their notebook

Launching and compiling:
	gcc main.c Evidence.c init.c defs.h -o <desiredFileName>
	valgrind ./<desiredFileName>
	Exit the code properly to avoid memory leaks and other potenial errors
