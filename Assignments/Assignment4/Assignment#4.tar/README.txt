Connor Gomes
101231686

Program prints ghosts to a screen in three different ways (Super interesting)
	1. By ID
	2. By Room
	3. By Likelihood

Compiling and launching
	1. Run "gcc main.c building.c room.c ghost.c defs.h -o <desiredFileName>"
	2. Run "valgrind ./<desiredFileName>"

